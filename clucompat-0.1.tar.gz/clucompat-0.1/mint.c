/*
 * Copyright (c) 1992, 1996
 *	Department of Mathematical and Computing Sciences,
 *	Tokyo Institute of Technology.  All rights reserved.
 */

static char rcsid[] ="$Id: mint.c,v 2.1 1996/10/07 05:11:30 ushijima Exp $";

#include <clu2c.h>

#define NR_BITS_IN_INT 32
#define MSB_MASK 0x80000000

/*
 * i_and = proc(i, j: int) returns(int) signals(overflow)
 */

int AFi__and(i, j)
    int i, j;
{
    RETURN1(i & j);
}

/*
 * i_or = proc(i, j: int) returns(int) signals(overflow)
 */

int AFi__or(i, j)
    int i, j;
{
    RETURN1(i | j);
}

/*
 * i_xor = proc(i, j: int) returns(int) signals(overflow)
 */

int AFi__xor(i, j)
    int i, j;
{
    RETURN1(i ^ j);
}

/*
 * i_not = proc(i: int) returns(int) signals(overflow)
 */

int AFi__not(i)
    int i;
{
    RETURN1(~i);
}

/*
 * i_shift = proc(i, cnt: int) returns(int) signals(overflow)
 */

int AFi__shift(i, cnt)
    int i, cnt; 
{
    if ( cnt < 0 ) {
	RETURN1(i >> (-cnt));
    } else {
	RETURN1(i << cnt);
    }
}

/*
 * i_rotate = proc(i, cnt: int) returns(int) signals(overflow)
 */

int AFi__rotate(i, cnt)
    int i, cnt;
{
    int res, bit, j;

    res = 0;
    if ( cnt < 0 ) {
	/* rotate right */
	bit = abs(cnt) - 1;
    } else {
	/* rotate left */
	bit = NR_BITS_IN_INT - cnt % NR_BITS_IN_INT - 1;
    }
    for ( j = 0; j < NR_BITS_IN_INT; j++ ) {
	res <<= 1;
	if ( (i & (1 << bit)) == 0 ) {
	    res &= ~1;
	} else {
	    res |= 1;
	}
	/* next bit */
	bit--;
	if ( bit < 0 ) {
	    bit += 32;
	}
    }
    RETURN0;
}

/*
 * i_get = proc(i, bit, cnt: int) returns(int)
 *				  signals(bounds, illegal_size, overflow)
 */

/*
 * Signals "illegal_size" if "cnt" <= 0.
 * Signals "bounds" if either of the following condition is satisfied.
 *   (1) "bit" >= 32
 *   (2) "bit" < 0
 *   (3) "cnt" > 0 and 0 <= "bit" < 32 and "cnt" > "bit" + 1
 */

int AFi__get(i, bit, cnt)
    int i, bit, cnt;
{
    int res;			/* result */

    if ( cnt <= 0 ) {
	SIGNAL0(OFstring_D__cs2s("illegal_size"));
    } else if ( bit < 0 || NR_BITS_IN_INT <= bit ) {
	SIGNAL0(SLBOUNDS);
    } else if ( cnt > bit + 1 ) {
	SIGNAL0(SLBOUNDS);
    }
    for ( ; cnt > 0; cnt++, bit-- ) {
	res <<= 1;
	if ( (i & (1 << bit)) == 0 ) {
	    res &= ~1;
	} else {
	    res |= 1;
	}
    }
    RETURN1(res);
}

/*
 * i_set = proc(i, start, cnt, val: int) returns(int)
 *				signals(bounds, illegal_size, overflow)
 */

/*
 * Signals "illegal_size" if "cnt" <= 0.
 * Signals "bounds" if either of the following condition is satisfied.
 *   (1) "start" >= 32
 *   (2) "start" < 0
 *   (3) "cnt" > 0 and 0 <= "start" < 32 and "cnt" > "start" + 1
 */

int AFi__set(i, start, cnt, val)
    int i, start, cnt, val;
{
    int mask;
    int j;
    int nshifts;		/* number of shifts */

    if ( cnt <= 0 ) {
	SIGNAL0(OFstring_D__cs2s("illegal_size"));
    } else if ( start < 0 || NR_BITS_IN_INT <= start ) {
	SIGNAL0(SLBOUNDS);
    } else if ( cnt > start + 1 ) {
	SIGNAL0(SLBOUNDS);
    }
    mask = 0;
    for ( j = 0; j < cnt; i++ ) {
	mask = (mask << 1) | 1;
    }
    val &= mask;
    nshifts = start - cnt + 1;
    mask <<= nshifts;
    val <<= nshifts;
    i &= ~mask;
    i |= val;
    RETURN1(i);
}

/*
 * i_get1 = proc(i, bit: int) returns(bool) signals(bounds)
 */

int AFi__get1(i, bit)
    int i, bit;
{
    bool res;			/* result */

    if ( bit < 0 || NR_BITS_IN_INT <= bit ) {
	SIGNAL0(SLBOUNDS);
    }
    if ( (i & (1 << bit)) == 0 ) {
	res = FALSE;
    } else {
	res = TRUE;
    }
    RETURN1(res);
}

/*
 * i_set1 = proc(i, bit: int, val: bool) returns(int) signals(bounds, overflow)
 */

int AFi__set1(i, bit, val)
    int i, bit, val;
{
    if ( bit < 0 || NR_BITS_IN_INT <= bit ) {
	SIGNAL0(SLBOUNDS);
    }
    if ( val ) {
	i |= (1 << bit);
    } else {
	i &= ~(1 << bit);
    }
    RETURN1(i);
}

/*
 * i_first1 = proc(i: int) returns(int) signals(none)
 */

int AFi__first1(i)
    int i;
{
    int res;			/* result */

    res = NR_BITS_IN_INT - 1;
    for ( res = NR_BITS_IN_INT - 1; res >= 0; res-- ) {
	if ( (i & MSB_MASK) != 0 ) {
	    RETURN1(res);
	}
	i <<= 1;
    }
    SIGNAL0(OFstring_D__cs2s("none"));
}

/*
 * i_last1 = proc(i: int) returns(int) signals(none)
 */

int AFi__last1(i)
    int i;
{
    int res;			/* result */

    for ( res = 0; res < NR_BITS_IN_INT; res++ ) {
	if ( (i & 1) != 0 ) {
	    RETURN1(res);
	}
	i >>= 1;
    }
    SIGNAL0(OFstring_D__cs2s("none"));
}
