#! /bin/sh

echo creating Makefile
echo '# Makefile.  Generated automatically by configure.' |
cat - config.mk files.mk defsunix.mk rules.mk >Makefile
