/*
 * _signal.c - signal handling support
 *
 * Copyright (c) 1992, 1996
 *	Department of Mathematical and Computing Sciences,
 *	Tokyo Institute of Technology.  All rights reserved.
 *
 * $Id: _signal.c,v 2.2 1996/10/07 05:11:31 ushijima Exp $
 */

#include <config/signal.h>

#include <clu2c.h>


/*
 * _signal = cluster is set, get, unset, set_message, get_message
 *
 *
 * OVERVIEW
 *
 * The `_signal' cluster provides facilities for signal handling.
 * Different from other clusters, there is no object of type
 * `_signal'.  Rather, it provides a set of operations for signal
 * handling.
 *
 * From the viewpoint of `_signal', each signal is in one of the three
 * states: INITIAL, BLOCKED, or COUNTED.  INITIAL state is a state at
 * the time any operation of `_signal' has not been invoked yet.
 * `_signal' has nothing to do with the interpretation of a signal in
 * INITIAL state.  Signals in BLOCKED state are blocked until they
 * transit to other states.  Signals in COUNTING state are simply
 * ignored but the number of occurrences are recorded.
 *
 * An optional message can be specified for each signal.  If a signal
 * is in COUNTING state and a message for it is specified, The
 * specified message is printed on standard output each time at the
 * delivery of the signal.
 */


/*
 * Type of signal handlers.
 */
typedef RETSIGTYPE (*handler_t)();

/*
 * Saved signal handlers.
 */
static handler_t saved_handlers[NSIG];

/*
 * Counters.
 */
static int counts[NSIG];

/*
 * Messages.
 */
static int messages[NSIG];


/*
 * Our own signal handler.
 */

static int OF__signal_Dhand(sig)
int sig;
{
    char *msg;

    counts[sig - 1]++;
    msg = messages[sig - 1];
    if (msg) {
	write(1, msg, strlen(msg));
    }
}


/*
 * Operations
 */


/*
 * All the operations that has "signals(bad_code)" clause in their
 * headings signal `bad_code' if an integer argument that should
 * represent a signal does not specify any signal.
 *
 * The description of each operation below omits things about this
 * exception and assumes that the argument specifies some signal.
 */


/*
 * set = proc(sig: int, hold: bool) signals(bad_code)
 *
 * Effects:
 *   	Blocks the signal SIG (i.e., SIG transits to BLOCKED state) if
 *	HOLD is true; otherwise SIG transits to COUNTING state, i.e.,
 *	(1) assigns a counting handler for the signal SIG, (2) saves
 *	the previous information about SIG (if possible), and (3)
 *	un-block SIG if it is in BLOCKED state.
 */

int OF__signal_Dset(sig, hold)
int sig;
bool hold;
{
    handler_t handler;
#if defined(SA_RESETHAND) || defined(SA_RESTART)
    struct sigaction act;
#endif

    if (sig <= 0 || NSIG <= sig) {
	SIGNAL0(OFstring_D__cs2s("bad_code"));
    }
    if (hold) {
	sighold(sig);
    } else {
	handler = signal(sig, OF__signal_Dhand);
	if (saved_handlers[sig - 1] == 0) {
	    saved_handlers[sig - 1] = handler;
	}
	sigrelse(sig);
#ifdef SA_RESETHAND
	sigaction(sig, 0, &act);
	act.sa_flags &= ~SA_RESETHAND;
	sigaction(sig, &act, 0);
#endif
#ifdef SA_RESTART
	sigaction(sig, 0, &act);
	act.sa_flags |= SA_RESTART;
	sigaction(sig, &act, 0);
#endif
    }
    RETURN0;
}


/*
 * unset = proc(sig: int) signals(bad_code)
 *
 * Effects:
 *   	Restores the previous signal infomation about the signal SIG
 *	(if possible) and puts SIG in INITIAL state.
 */

int OF__signal_Dunset(sig)
int sig;
{
    if (sig <= 0 || NSIG <= sig) {
	SIGNAL0(OFstring_D__cs2s("bad_code"));
    }
    if (saved_handlers[sig - 1]) {
	signal(sig, saved_handlers[sig - 1]);
	saved_handlers[sig - 1] = 0;
    }
    sigrelse(sig);
    RETURN0;
}


/*
 * get = proc(sig: int) returns(int) signals(bad_code)
 *
 * Effects:
 *   	Returns the number of occurrence of the signal SIG since the
 *	last invocation of `get' operation if SIG is in COUNTING sate.
 */

int OF__signal_Dget(sig)
int sig;
{
    int res;

    if (sig <= 0 || NSIG <= sig) {
	SIGNAL0(OFstring_D__cs2s("bad_code"));
    }
    res = counts[sig - 1];
    counts[sig - 1] = 0;
    RETURN1(res);
}


/*
 * set_message = proc(sig: int, msg: string) signals(bad_code)
 *
 * Effects:
 *	Sets an optional message for the signal SIG.
 */

int OF__signal_Dset__message(sig, msg)
int sig;
string msg;
{
    if (sig <= 0 || NSIG <= sig) {
	SIGNAL0(OFstring_D__cs2s("bad_code"));
    }
    messages[sig - 1] = OFstring_D__s2cs(msg);
    RETURN0;
}


/*
 * get_message = proc(sig: int) returns(string) signals(bad_code)
 *
 * Effects:
 *   	Gets the optional message for the signal SIG if previously
 *	specified.
 */

int OF__signal_Dget__message(sig)
int sig;
{
    string msg;

    if (sig <= 0 || NSIG <= sig) {
	SIGNAL0(OFstring_D__cs2s("bad_code"));
    }
    if (messages[sig - 1] == 0) {
	msg = SLNULL;
    } else {
	msg = OFstring_D__cs2s(messages[sig - 1]);
    }
    RETURN1(msg);
}
