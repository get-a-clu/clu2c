/*
 * type.h - type definitions
 *
 * Copyright (c) 1992, 1996
 *	Department of Mathematical and Computing Sciences,
 *	Tokyo Institute of Technology.  All rights reserved.
 *
 * $Id: type.h,v 2.8 1996/10/07 02:59:56 ushijima Exp $
 */

#include <clu2c.h>
